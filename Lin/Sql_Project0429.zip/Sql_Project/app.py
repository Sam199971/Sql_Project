from flask import Flask, render_template, request, jsonify, session , url_for,redirect
import pyodbc, array, json
from datetime import datetime, date, time
from jinja2 import Template

app = Flask(__name__)
app.secret_key = 'ahoy'
# 連接mssql

server = 'LAPTOP-5GRQ8RBR\SQLEXPRESS'
database = 'SQL_Class'
username = 'sa'
password = 'micky5630'

sqlConn = pyodbc.connect(
    'DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + server + ';DATABASE=' + database + ';UID=' + username + ';PWD=' + password)

cursor = sqlConn.cursor()


#查詢的網頁
# @app.route('/', methods = ["GET", "POST"])
# def hello_world():
#
#     cursor.execute("Select sType From [Space] GROUP BY sType")
#     types = cursor.fetchall()
#
#     if request.method == 'POST':
#         date = request.form['bday']  #前端輸入的日期 post進來的
#         sType = request.form['sel']  #前端輸入的場地類型
#         print(date)
#         print(sType)
#         FindNullSpace(date, sType)   #查詢空的時段
#
#         return render_template('Search.html', types=types, date = date, sel = sType)
#     else:
#         return render_template('Search.html', types=types)
#
@app.route('/', methods=["GET", "POST"])
def Home():
    session['loggedin'] = False
    session['uname'] = ""
    if request.method == 'POST':
        uname = request.form['Name']
        uaccount = request.form['Account']
        upassword = request.form['Password']
        if 'login' in request.form:   # login form #
            cursor.execute("""SELECT uId as fetchId FROM [user]""")
            uId = cursor.fetchall()
            print(uId[0].fetchId)
            for x in uId:
                cursor.execute("""SELECT * FROM [User] WHERE uId = ? """, x.fetchId)
                TargetUser = cursor.fetchall()
                # print(TargetUser[0].uName)
                if uname == TargetUser[0].uName and uaccount == TargetUser[0].uAccount and upassword == TargetUser[0].uPassword:
                    print('login success')
                    LoginStatus = 'True'
                    Loginname = TargetUser[0].uName
                    session['uname'] = uname
                    session['loggedin'] = True
                    session['uId'] = TargetUser[0].uId
                    break
                else:
                    LoginStatus = 'False'
            if LoginStatus == 'True':
                return render_template('home.html', LoginStatus=session['loggedin'], Loginname=session['uname'])
                # return redirect(url_for('Search', Loginname=Loginname))
                # return redirect(url_for('Purchase'))
            else:
                return render_template('home.html', LoginStatus=session['loggedin'])
        elif 'Register' in request.form:  # register form #
            cursor.execute("""SELECT max(uId) as MaxUID FROM [user]""")
            LastId = cursor.fetchall()
            print(LastId[0])
            LastId[0].MaxUID += 1
            # cursor.execute("""INSERT INTO [User] VALUES (?, ?, ?,?);""", LastId[0].MaxUID, uName, uAccount, uPassword)
            # cursor.commit()
            cursor.execute("""Select * From [User]""")
            alluser = cursor.fetchall()
            print(alluser)
            return render_template('home.html', Name=uname, Account=uaccount, Password=upassword, TestId=LastId)
    else:
        return render_template('home.html', LoginStatus=session['loggedin'])
# @app.route('/', methods = ["GET", "POST"])
# def home():
#     return render_template('purchase.html')


@app.route('/purchase')
def Purchase():
    if 'loggedin' in session:
        cursor.execute("""Select * From [User]""")
        return render_template('purchase.html')
    else:
        return render_template('home.html')

#查詢包廂的網頁
# @app.route('/Search?Loginname=<Loginname>')
# def Search(Loginname):
#     cursor.execute("Select sType From [Space] GROUP BY sType")
#     types = cursor.fetchall()
#     return render_template('Search.html', Alltypes=types, Loginname=Loginname)
@app.route('/Search')
def Search():
    # if session['loggedin'] == True:
        cursor.execute("Select sType From [Space] GROUP BY sType")
        types = cursor.fetchall()
        Loginname = session['uname']
        return render_template('Search.html', Alltypes=types, Loginname=Loginname, Status=session['loggedin'])
    # else:
    #     return render_template('home.html')


# 查詢空的時段 新的
def FindNullSpace(date, sType):
    cursor.execute("""
            Select *                                                 
            From [Space] as S
            Where S.sType = ?
            """, sType)  # 用sType找此場地類型的所有場地
    SpaceNames = cursor.fetchall()

    columns = [{"title": "Time", "data": "time"}]
    for s in SpaceNames:
        columns.append({"title": str(s.sId), "data": str(s.sId)})

    data = []
    for i in range(24):
        d = {'time': str(i)}
        d.update([(str(s.sId), str(s.sId)) for s in SpaceNames])
        data.append(d)

    for s in SpaceNames:  # 每個場地的空閒時間判斷
        cursor.execute("""
            Select *                                             
            From SpaceTime as ST inner join [Space] as S
            on ST.sId = S.[sid]
            Where Date = ?  and S.sId = ?;
            """, date, s.sId)  # 用sType 跟Date找每個場地找Date 當天的借閱紀錄
        SpaceOfDate_Record = cursor.fetchall()  # 每個場地當天的借閱紀錄 - 陣列裡面放dict

        for Record in SpaceOfDate_Record:
            # print('第 {} 間場地第 {} 筆記錄有 {}小時 '.format(SpaceOfDate_Record[RecordNumber].sId, RecordNumber + 1,
            #                                        SpaceOfDate_Record[
            #                                            RecordNumber].TotalTime))  # 找第i筆紀錄的 sId 跟TotalTime
            # print(SpaceOfDate_Record[RecordNumber].StartTime.hour)

            RecordTimesLen = Record.TotalTime
            RecordStartTime = int(Record.StartTime.hour)

            for timeSection in range(RecordTimesLen):
                data[RecordStartTime + timeSection][str(s.sId)] = ''

    resp_data = {
        "columns": columns,
        "data": data,
        "targets": [i for i in range(1, len(columns))]
    }

    return resp_data

# 新的
@app.route('/data', methods=["POST", "GET"])
def data():
    date = request.get_json()

    if date["date"] != '' and date["sType"] != "":
        resp = FindNullSpace(date["date"], date["sType"])
        return jsonify(resp)

# 查詢包廂的網頁
# @app.route('/', methods=["GET"])
# def hello_world():
#     cursor.execute("Select sType From [Space] GROUP BY sType")
#     types = cursor.fetchall()
#
#     return render_template('home.html', Alltypes=types)

#回傳purchase網頁
@app.route('/purchase', methods=["POST", "GET"])
def ReturnPurchase():
    if request.method == 'POST':
        UserDetail = {}
        UserDetail["UserName"] = request.form["UserName"]
        UserDetail["Date"] = request.form["Date"]
        UserDetail["SType"] = request.form["SType"]
        UserDetail["SName"] = request.form["SName"]
        UserDetail["StartTime"] = request.form["StartTime"]
        UserDetail["TotalTime"] = request.form["TotalTime"]
        print(UserDetail)
        cursor.execute("""Select PricePerHour From [Space] Where sType = ?""", UserDetail["SType"])

        PricePerHour = cursor.fetchone()

        print(PricePerHour)


        # TodayDate = date.today()


        InputDate = datetime.strptime(UserDetail["Date"], "%Y-%m-%d").date()
        print(InputDate)




        StartTime = time(int(UserDetail["StartTime"]))
        print(StartTime)

        EndTime = time(int(UserDetail["StartTime"])+int(UserDetail["TotalTime"]))
        TotalPrice = int(UserDetail["TotalTime"]) * PricePerHour.PricePerHour

        cursor.execute("""Insert into SpaceTime values(?, ?, ?, ?, ?, ?, ?)""", UserDetail["SName"], session['uId'], InputDate,
                            StartTime, EndTime, UserDetail["TotalTime"], TotalPrice)
        cursor.commit()

        return redirect(url_for('Purchase'))





@app.route('/logout')
def logout():
    # Remove session data, this will log the user out
   session.pop('loggedin', None)
   # Redirect to login page
   return redirect(url_for('Home'))


if __name__ == '__main__':
    app.run()
    # for i in range(10001, 50000):
    #     i = str(i)
    #     cursor.execute("""INSERT INTO [User] Values (?, ?, ?,?)""", i, i, i, i)
    #     cursor.commit()
